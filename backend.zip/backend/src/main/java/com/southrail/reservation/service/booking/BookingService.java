package com.southrail.reservation.service.booking;

import com.southrail.reservation.dto.booking.BookingDtos;
import com.southrail.reservation.entity.account.RoleName;
import com.southrail.reservation.entity.account.User;
import com.southrail.reservation.entity.booking.Booking;
import com.southrail.reservation.entity.booking.BookingSeat;
import com.southrail.reservation.entity.booking.BookingStatus;
import com.southrail.reservation.entity.booking.Passenger;
import com.southrail.reservation.entity.train.RouteStop;
import com.southrail.reservation.entity.train.Station;
import com.southrail.reservation.entity.train.Train;
import com.southrail.reservation.exception.ApiException;
import com.southrail.reservation.repository.account.UserRepository;
import com.southrail.reservation.repository.booking.BookingRepository;
import com.southrail.reservation.repository.booking.PassengerRepository;
import com.southrail.reservation.repository.train.RouteStopRepository;
import com.southrail.reservation.repository.train.StationRepository;
import com.southrail.reservation.repository.train.TrainRepository;
import com.southrail.reservation.service.audit.AuditLogService;
import com.southrail.reservation.service.notification.EmailNotificationService;
import com.southrail.reservation.util.train.RailwayTime;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BookingService {
  private final BookingRepository bookings;
  private final PassengerRepository passengers;
  private final UserRepository users;
  private final TrainRepository trains;
  private final StationRepository stations;
  private final RouteStopRepository routeStops;
  private final SeatAllocationService seatAllocationService;
  private final SecureRandom random = new SecureRandom();
  private final EmailNotificationService accountEmailService;
  private final AuditLogService auditLogService;
  private final FareCalculationService fareCalculationService;
  private static final Logger log = LoggerFactory.getLogger(BookingService.class);
  static final int RAC_LIMIT = 10;
  public BookingService(BookingRepository bookings, PassengerRepository passengers, UserRepository users,
      TrainRepository trains, StationRepository stations, RouteStopRepository routeStops,
      SeatAllocationService seatAllocationService, EmailNotificationService accountEmailService,
      AuditLogService auditLogService) {
    this(bookings, passengers, users, trains, stations, routeStops, seatAllocationService,
        accountEmailService, auditLogService, new FareCalculationService());
  }

  @Autowired
  public BookingService(BookingRepository bookings, PassengerRepository passengers, UserRepository users,
      TrainRepository trains, StationRepository stations, RouteStopRepository routeStops,
      SeatAllocationService seatAllocationService, EmailNotificationService accountEmailService,
      AuditLogService auditLogService, FareCalculationService fareCalculationService) {
    this.bookings = bookings;
    this.passengers = passengers;
    this.users = users;
    this.trains = trains;
    this.stations = stations;
    this.routeStops = routeStops;
    this.seatAllocationService = seatAllocationService;
    this.accountEmailService=accountEmailService;
    this.auditLogService=auditLogService;
    this.fareCalculationService = fareCalculationService;
  }

  @Transactional
  public BookingDtos.BookingResponse create(String email, BookingDtos.BookingRequest request) {
    return create(email, null, request);
  }

  @Transactional
  public BookingDtos.BookingResponse create(String email, String idempotencyKey, BookingDtos.BookingRequest request) {
    User user = users.findByEmailIgnoreCase(email).orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "User not found"));
    String normalizedKey = normalizeIdempotencyKey(idempotencyKey);
    String requestFingerprint = normalizedKey == null ? null : fingerprint(request);
    if (normalizedKey != null) {
      bookings.acquireScopedLock("booking-request:" + user.getId() + ":" + normalizedKey);
      Booking existing = bookings.findByUserAndIdempotencyKey(user, normalizedKey).orElse(null);
      if (existing != null) {
        if (!requestFingerprint.equals(existing.getIdempotencyFingerprint())) {
          throw new ApiException(HttpStatus.CONFLICT,
              "Idempotency-Key has already been used for a different booking request");
        }
        return toResponse(existing, Math.toIntExact(passengers.countByBooking(existing)));
      }
    }
    UUID trainId = parseTrainId(request.getTrainId());
    String travelClass = request.getTravelClass().toUpperCase(Locale.ROOT);
    bookings.acquireScopedLock("inventory:" + trainId + ":" + request.getJourneyDate() + ":" + travelClass);
    Train train = trains.findById(trainId).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Train not found"));
    Station source = stations.findByCodeIgnoreCase(request.getSourceStationCode()).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Source station not found"));
    Station destination = stations.findByCodeIgnoreCase(request.getDestinationStationCode()).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Destination station not found"));
    JourneyStops journeyStops = validateJourney(train, source, destination, request.getJourneyDate(), request.getTravelClass());
    int passengerCount = request.getPassengers().size();

    int availableSeats = seatAllocationService.getAvailableSeatCount(
            train,
            request.getJourneyDate(),
            travelClass);

    BookingStatus bookingStatus;
    Integer queuePosition = null;
    String reservationLabel;
    long racPassengerCount = bookings.countQueuedPassengers(
        train.getId(), request.getJourneyDate(), travelClass, BookingStatus.RAC);
    boolean waitlistExists = hasQueuedBookings(
        train.getId(), request.getJourneyDate(), travelClass, BookingStatus.WAITLISTED);

    // Existing queued parties always have priority over a newcomer.
    if (availableSeats >= passengerCount && racPassengerCount == 0 && !waitlistExists) {
      bookingStatus = BookingStatus.CONFIRMED;
      reservationLabel = "CNF";
    } else {
      if (!waitlistExists && racPassengerCount + passengerCount <= RAC_LIMIT) {
        bookingStatus = BookingStatus.RAC;
        queuePosition = bookings.findMaximumQueuePosition(
            train.getId(), request.getJourneyDate(), travelClass, BookingStatus.RAC) + 1;
        reservationLabel = "RAC " + queuePosition;
      } else {
        bookingStatus = BookingStatus.WAITLISTED;
        queuePosition = bookings.findMaximumQueuePosition(
            train.getId(), request.getJourneyDate(), travelClass, BookingStatus.WAITLISTED) + 1;
        reservationLabel = "WL " + queuePosition;
      }
    }

    Booking booking = new Booking();
    booking.setUser(user);
    booking.setTrain(train);
    booking.setSourceStation(source);
    booking.setDestinationStation(destination);
    booking.setJourneyDate(request.getJourneyDate());
    booking.setTravelClass(travelClass);
    booking.setQuota(request.getQuota().toUpperCase(Locale.ROOT));
    booking.setPnr(generateUniquePnr());
    booking.setStatus(bookingStatus);
    booking.setQueuePosition(queuePosition);
    booking.setReservationLabel(reservationLabel);
    booking.setIdempotencyKey(normalizedKey);
    booking.setIdempotencyFingerprint(requestFingerprint);
    booking.setTotalFare(calculateFare(request, journeyStops).total());
    bookings.save(booking);

    List<Passenger> savedPassengers = request.getPassengers().stream().map(item -> {
      Passenger passenger = new Passenger();
      passenger.setBooking(booking);
      passenger.setFullName(item.getFullName().trim());
      passenger.setAge(item.getAge());
      passenger.setGender(item.getGender().toUpperCase(Locale.ROOT));
      passenger.setBerthPreference(
              item.getBerthPreference() == null
                      ? null
                      : item.getBerthPreference().toUpperCase(Locale.ROOT));
      passenger.setStatus(bookingStatus);
      return passengers.save(passenger);
    }).collect(Collectors.toList());
    List<BookingSeat> allocatedSeats = Collections.emptyList();

    if (bookingStatus == BookingStatus.CONFIRMED) {
      allocatedSeats = seatAllocationService.allocateSeats(
              booking,
              savedPassengers);
    }
    auditLogService.log(
            user.getId(),
            user.getEmail(),
            "BOOKING_CREATED",
            "BOOKING",
            "Ticket booked with status " + booking.getReservationLabel()
                    + " and PNR: " + booking.getPnr()
    );
    if (bookingStatus == BookingStatus.WAITLISTED) {
      auditLogService.log(user.getId(), user.getEmail(), "WAITLIST_CREATED", "BOOKING",
          "Waitlist booking created; PNR: " + booking.getPnr()
              + "; status: " + booking.getReservationLabel());
    }
    if (bookingStatus == BookingStatus.CONFIRMED) {
      accountEmailService.sendBookingConfirmation(
              booking,
              savedPassengers,
              allocatedSeats);
    }
    return toResponse(booking, request.getPassengers().size());
  }

  private BookingDtos.BookingResponse toResponse(Booking booking, int passengerCount) {
    Train train = booking.getTrain();
    Station source = booking.getSourceStation();
    Station destination = booking.getDestinationStation();
    return new BookingDtos.BookingResponse(booking.getId().toString(), booking.getPnr(), booking.getStatus().name(),
        train.getNumber(), train.getName(),
        source.getCode(), source.getName(),
        destination.getCode(), destination.getName(),
        booking.getJourneyDate(),
        booking.getTravelClass(),
        passengerCount,
        booking.getTotalFare(),
        "NOT_COLLECTED",booking.getReservationLabel(),
            booking.getQueuePosition());
  }

  private String normalizeIdempotencyKey(String key) {
    if (key == null || key.isBlank()) return null;
    String normalized = key.trim();
    if (normalized.length() > 128) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "Idempotency-Key must not exceed 128 characters");
    }
    return normalized;
  }

  private String fingerprint(BookingDtos.BookingRequest request) {
    StringBuilder canonical = new StringBuilder()
        .append(request.getTrainId()).append('\n')
        .append(request.getSourceStationCode().toUpperCase(Locale.ROOT)).append('\n')
        .append(request.getDestinationStationCode().toUpperCase(Locale.ROOT)).append('\n')
        .append(request.getJourneyDate()).append('\n')
        .append(request.getTravelClass().toUpperCase(Locale.ROOT)).append('\n')
        .append(request.getQuota().toUpperCase(Locale.ROOT)).append('\n');
    request.getPassengers().forEach(passenger -> canonical
            .append(passenger.getFullName().trim()).append('\u001f')
        .append(passenger.getAge()).append('\u001f')
            .append(passenger.getGender().toUpperCase(Locale.ROOT)).append('\u001f')
            .append(passenger.getBerthPreference() == null ? null
                            : passenger.getBerthPreference().toUpperCase(Locale.ROOT))
            .append('\n'));
    try {
      byte[] digest = MessageDigest.getInstance("SHA-256")
          .digest(canonical.toString().getBytes(StandardCharsets.UTF_8));
      return java.util.HexFormat.of().formatHex(digest);
    } catch (java.security.NoSuchAlgorithmException ex) {
      throw new IllegalStateException("SHA-256 is unavailable", ex);
    }
  }

  @Transactional(readOnly = true)
  public BookingDtos.BookingReview review(BookingDtos.BookingRequest request) {
    Train train = trains.findById(parseTrainId(request.getTrainId())).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Train not found"));
    Station source = stations.findByCodeIgnoreCase(request.getSourceStationCode()).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Source station not found"));
    Station destination = stations.findByCodeIgnoreCase(request.getDestinationStationCode()).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Destination station not found"));
    JourneyStops journeyStops = validateJourney(train, source, destination, request.getJourneyDate(), request.getTravelClass());

    FareCalculationService.Fare fare = calculateFare(request, journeyStops);
    String travelClass = request.getTravelClass().toUpperCase(Locale.ROOT);
    int physicalSeats = seatAllocationService.getAvailableSeatCount(
        train, request.getJourneyDate(), travelClass);
    long racPassengerCount = bookings.countQueuedPassengers(
        train.getId(), request.getJourneyDate(), travelClass, BookingStatus.RAC);
    boolean waitlistExists = hasQueuedBookings(
        train.getId(), request.getJourneyDate(), travelClass, BookingStatus.WAITLISTED);
    boolean queuedBookingsExist = racPassengerCount > 0 || waitlistExists;
    int availableSeats = queuedBookingsExist ? 0 : physicalSeats;
    String availabilityMessage;
    if (availableSeats >= request.getPassengers().size()) {
      availabilityMessage = availableSeats < 18 ? "Limited seats" : "Available";
    } else if (!waitlistExists
        && racPassengerCount + request.getPassengers().size() <= RAC_LIMIT) {
      availabilityMessage = "Confirmed seats unavailable. RAC will be assigned";
    } else {
      availabilityMessage = "Confirmed seats unavailable. Waitlist will be assigned";
    }

    return new BookingDtos.BookingReview(
        fare.baseFare(),
        fare.reservationCharge(),
        fare.convenienceFee(),
        fare.gst(),
        fare.total(),
        availableSeats,
        availabilityMessage,
        Arrays.asList(
            new BookingDtos.FareLine("Base fare", fare.baseFare()),
            new BookingDtos.FareLine("Reservation charge", fare.reservationCharge()),
            new BookingDtos.FareLine("Convenience fee", fare.convenienceFee()),
            new BookingDtos.FareLine("GST", fare.gst())),
        request.getPassengers().stream()
            .map(passenger -> new BookingDtos.BerthSuggestion(passenger.getFullName(), berthSuggestion(passenger.getAge(), passenger.getBerthPreference()),
                passenger.getAge() > 58 ? "Senior passenger comfort" : "Based on selected preference"))
            .collect(Collectors.toList()),
        Arrays.asList("Cancellation before departure is eligible for refund after railway charges",
            "The complete booking may be cancelled before departure",
            "Refund is routed to the original payment method"));
  }

  @Transactional(readOnly = true)
  public BookingDtos.PnrStatus pnr(String email, String pnr) {
    User currentUser = users.findByEmailIgnoreCase(email)
        .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "User not found"));
    Booking booking = bookings.findByPnr(pnr).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "PNR not found"));
    if (!currentUser.getRoles().contains(RoleName.ROLE_ADMIN)
        && !booking.getUser().getId().equals(currentUser.getId())) {
      throw new ApiException(HttpStatus.FORBIDDEN, "You are not allowed to access this booking");
    }
    List<Passenger> bookingPassengers = passengers.findByBooking(booking);
    java.util.Map<UUID, BookingSeat> seatsByPassenger = seatAllocationService
        .bookedSeatsForBooking(booking).stream()
        .collect(Collectors.toMap(seat -> seat.getPassenger().getId(), seat -> seat));
    List<BookingDtos.PnrPassenger> passengerDetails = bookingPassengers.stream().map(passenger -> {
      BookingSeat seat = seatsByPassenger.get(passenger.getId());
      return new BookingDtos.PnrPassenger(
          passenger.getFullName(),
          passenger.getStatus().name(),
          passenger.getStatus() == BookingStatus.WAITLISTED ? booking.getQueuePosition() : null,
          seat == null ? null : seat.getCoachCode() + "/" + seat.getSeatNumber());
    }).collect(Collectors.toList());
    return new BookingDtos.PnrStatus(
        booking.getPnr(),
        booking.getTrain().getNumber(),
        booking.getTrain().getName(),
        booking.getSourceStation().getCode(),
        booking.getSourceStation().getName(),
        booking.getDestinationStation().getCode(),
        booking.getDestinationStation().getName(),
        booking.getJourneyDate(),
        booking.getTravelClass(),
        booking.getQuota(),
        booking.getStatus().name(),
        bookingPassengers.stream().map(passenger -> passenger.getFullName() + " - " + passenger.getStatus()).collect(Collectors.toList()),
        booking.getStatus() == BookingStatus.CANCELLED && booking.getRefundAmount() != null
            ? booking.getRefundAmount() : BigDecimal.ZERO,
        booking.getTotalFare(), booking.getReservationLabel(),
        booking.getQueuePosition(), passengerDetails);
  }

  @Transactional(readOnly = true)
  public Page<BookingDtos.BookingHistoryItem> history(String email, Pageable pageable) {
    User user = users.findByEmailIgnoreCase(email).orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "User not found"));
    return bookings.findByUserOrderByCreatedAtDesc(user, pageable)
        .map(booking -> new BookingDtos.BookingHistoryItem(
            booking.getId().toString(),
            booking.getPnr(),
            booking.getTrain().getId().toString(),
            booking.getTrain().getNumber(),
            booking.getTrain().getName(),
            booking.getSourceStation().getCode(),
            booking.getSourceStation().getName(),
            booking.getDestinationStation().getCode(),
            booking.getDestinationStation().getName(),
            booking.getJourneyDate(),
            booking.getStatus().name(),
            booking.getTotalFare(),booking.getReservationLabel(),
                booking.getQueuePosition()));
  }

  private String generateUniquePnr() {
    // Keep the uniqueness check and insert collision-free across bookings for
    // different trains; the advisory lock is held until this transaction ends.
    bookings.acquirePnrGenerationLock();
    for (int attempt = 0; attempt < 100; attempt++) {
      String candidate = String.valueOf(
          1000000000L + Math.floorMod(random.nextLong(), 8999999999L));
      if (!bookings.existsByPnr(candidate)) {
        return candidate;
      }
    }
    throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE,
        "Unable to generate a booking reference. Please retry.");
  }

  private boolean hasQueuedBookings(UUID trainId, LocalDate journeyDate, String travelClass,
      BookingStatus status) {
    return bookings.countByTrainIdAndJourneyDateAndTravelClassAndStatus(
        trainId, journeyDate, travelClass, status) > 0;
  }

  private UUID parseTrainId(String trainId) {
    try {
      return UUID.fromString(trainId);
    } catch (IllegalArgumentException ex) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "Train id must be a valid UUID");
    }
  }

  private JourneyStops validateJourney(Train train, Station source, Station destination, LocalDate journeyDate,
      String travelClass) {
    if (!train.isActive()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "Train is inactive");
    }
    if (source.getId().equals(destination.getId())) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "Source and destination must be different");
    }
    RouteStop sourceStop = routeStops.findFirstByTrainAndStationOrderByStopOrderAsc(train, source)
        .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "Source station is not on the selected train route"));
    RouteStop destinationStop = routeStops.findFirstByTrainAndStationOrderByStopOrderAsc(train, destination)
        .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST, "Destination station is not on the selected train route"));
    if (sourceStop.getStopOrder() >= destinationStop.getStopOrder()) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "Source must precede destination on the selected train route");
    }
    if (sourceStop.getDepartureTime() == null) {
      throw new ApiException(HttpStatus.BAD_REQUEST,
          "Selected source station does not have a departure time");
    }
    Instant departure = RailwayTime.departureInstant(
        journeyDate, sourceStop.getDayOffset(), sourceStop.getDepartureTime());
    if (!departure.isAfter(Instant.now())) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "Selected journey has already departed");
    }
    if (seatAllocationService.getConfiguredCapacity(train, travelClass) <= 0) {
      throw new ApiException(HttpStatus.BAD_REQUEST, "Travel class is not configured for the selected train");
    }
    return new JourneyStops(sourceStop, destinationStop);
  }

  private FareCalculationService.Fare calculateFare(BookingDtos.BookingRequest request,
      JourneyStops stops) {
    int distance = stops.destination().getDistanceKm() - stops.source().getDistanceKm();
    return fareCalculationService.quote(distance, request.getTravelClass(), request.getPassengers().size());
  }

  private String berthSuggestion(int age, String preference) {
    if (age > 58) {
      return "LOWER";
    }
    return preference == null || preference.trim().isEmpty() ? "NO_PREFERENCE" : preference;
  }

  private record JourneyStops(RouteStop source, RouteStop destination) {}

  @Transactional(readOnly = true)
  public Booking findById(UUID id) {
    return bookings.findById(id).orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Booking not found"));
  }
}
