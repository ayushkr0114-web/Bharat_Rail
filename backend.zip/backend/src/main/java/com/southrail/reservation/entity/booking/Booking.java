package com.southrail.reservation.entity.booking;

import com.southrail.reservation.entity.common.BaseEntity;
import com.southrail.reservation.entity.account.User;
import com.southrail.reservation.entity.train.Train;
import com.southrail.reservation.entity.train.Station;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "bookings")
public class Booking extends BaseEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.UUID)
  private UUID id;

  @Column(nullable = false, unique = true, length = 12)
  private String pnr;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "user_id")
  private User user;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "train_id")
  private Train train;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "source_station_id")
  private Station sourceStation;

  @ManyToOne(fetch = FetchType.LAZY, optional = false)
  @JoinColumn(name = "destination_station_id")
  private Station destinationStation;

  @Column(nullable = false)
  private LocalDate journeyDate;

  @Column(nullable = false, length = 5)
  private String travelClass;

  @Column(nullable = false, length = 20)
  private String quota;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false)
  private BookingStatus status;

  @Column(nullable = false, precision = 10, scale = 2)
  private BigDecimal totalFare;

  @Column(precision = 10, scale = 2)
  private BigDecimal refundAmount;

  @Column(precision = 10, scale = 2)
  private BigDecimal cancellationCharge;
  @Column(name = "queue_position")
  private Integer queuePosition;

  @Column(name = "reservation_label", length = 20)
  private String reservationLabel;

  @Column(name = "idempotency_key", length = 128)
  private String idempotencyKey;

  @Column(name = "idempotency_fingerprint", length = 64)
  private String idempotencyFingerprint;
}
