package com.southrail.reservation.repository.account;

import com.southrail.reservation.entity.account.User;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;

public interface UserRepository extends JpaRepository<User, UUID> {
  Optional<User> findByEmailIgnoreCase(String email);
  @Lock(LockModeType.PESSIMISTIC_WRITE)
  @Query("select u from User u where lower(u.email) = lower(:email)")
  Optional<User> findByEmailIgnoreCaseForUpdate(@Param("email") String email);
  boolean existsByEmailIgnoreCase(String email);
  Optional<User> findByAuthProviderAndProviderSubject(String authProvider, String providerSubject);

  /** Serializes creation for an identity that does not have a row to pessimistically lock yet. */
  @Query(value = "select pg_advisory_xact_lock(hashtextextended(:identity, 0))", nativeQuery = true)
  Object lockExternalIdentity(@Param("identity") String identity);
}
