package com.southrail.reservation.service.booking;

import com.southrail.reservation.dto.booking.RefundQuoteDto;
import com.southrail.reservation.entity.booking.Booking;
import com.southrail.reservation.entity.train.RouteStop;
import com.southrail.reservation.repository.train.RouteStopRepository;
import com.southrail.reservation.util.train.RailwayTime;
import com.southrail.reservation.exception.ApiException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpStatus;

@Service
public class RefundCalculationService {
  private final RouteStopRepository routeStops;

  public RefundCalculationService(RouteStopRepository routeStops) {
    this.routeStops = routeStops;
  }

  public RefundQuoteDto calculate(Booking booking) {
    BigDecimal refundPercentage = refundPercentage(resolveDepartureInstant(booking));
    BigDecimal totalFare = booking.getTotalFare().setScale(2, RoundingMode.HALF_UP);
    BigDecimal refundAmount = totalFare
        .multiply(refundPercentage)
        .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
    BigDecimal cancellationCharge = totalFare.subtract(refundAmount).setScale(2, RoundingMode.HALF_UP);

    return new RefundQuoteDto(
        totalFare,
        refundAmount,
        cancellationCharge,
        refundPercentage.setScale(2, RoundingMode.HALF_UP),
        policyMessage(refundPercentage));
  }

  private Instant resolveDepartureInstant(Booking booking) {
    return routeStops.findFirstByTrainAndStationOrderByStopOrderAsc(booking.getTrain(), booking.getSourceStation())
        .filter(stop -> stop.getDepartureTime() != null)
        .map(stop -> RailwayTime.departureInstant(
            booking.getJourneyDate(), stop.getDayOffset(), stop.getDepartureTime()))
        .orElseThrow(() -> new ApiException(HttpStatus.BAD_REQUEST,
            "Selected source station does not have a departure time"));
  }

  public boolean hasDeparted(Booking booking) {
    return !resolveDepartureInstant(booking).isAfter(Instant.now());
  }

  private BigDecimal refundPercentage(Instant departureInstant) {
    Duration timeUntilJourney = Duration.between(Instant.now(), departureInstant);

    if (timeUntilJourney.compareTo(Duration.ofHours(48)) > 0) {
      return BigDecimal.valueOf(90);
    }
    if (timeUntilJourney.compareTo(Duration.ofHours(24)) >= 0) {
      return BigDecimal.valueOf(75);
    }
    if (timeUntilJourney.compareTo(Duration.ofHours(4)) >= 0) {
      return BigDecimal.valueOf(50);
    }
    return BigDecimal.valueOf(0);
  }

  private String policyMessage(BigDecimal refundPercentage) {
    if (refundPercentage.compareTo(BigDecimal.valueOf(90)) == 0) {
      return "More than 48 hours before journey: 90% refund.";
    }
    if (refundPercentage.compareTo(BigDecimal.valueOf(75)) == 0) {
      return "24 to 48 hours before journey: 75% refund.";
    }
    if (refundPercentage.compareTo(BigDecimal.valueOf(50)) == 0) {
      return "4 to 24 hours before journey: 50% refund.";
    }
    return "Less than 4 hours before journey: no refund is applicable.";
  }
}
