package com.southrail.reservation.service.booking;

import com.southrail.reservation.entity.booking.*;
import com.southrail.reservation.repository.booking.*;
import com.southrail.reservation.service.booking.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.southrail.reservation.entity.account.RoleName;
import com.southrail.reservation.entity.account.User;
import com.southrail.reservation.repository.account.UserRepository;
import com.southrail.reservation.entity.train.Station;
import com.southrail.reservation.repository.train.StationRepository;
import com.southrail.reservation.entity.train.Train;
import com.southrail.reservation.repository.train.TrainRepository;
import com.southrail.reservation.entity.train.RouteStop;
import com.southrail.reservation.repository.train.RouteStopRepository;
import com.southrail.reservation.entity.booking.BookingSeat;
import com.southrail.reservation.repository.booking.BookingSeatRepository;
import com.southrail.reservation.entity.booking.BookingSeatStatus;
import com.southrail.reservation.entity.booking.Coach;
import com.southrail.reservation.repository.booking.CoachRepository;
import com.southrail.reservation.entity.auth.AccountToken;
import com.southrail.reservation.repository.auth.AccountTokenRepository;
import com.southrail.reservation.service.auth.AuthService;
import com.southrail.reservation.dto.auth.AuthDtos;
import com.southrail.reservation.exception.ApiException;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Files;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import javax.sql.DataSource;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@SpringBootTest
@ActiveProfiles("test")
@Testcontainers(disabledWithoutDocker = true)
class PostgresQueueIntegrationTest {

  @Container
  static final PostgreSQLContainer<?> POSTGRES = new PostgreSQLContainer<>("postgres:16-alpine");

  @DynamicPropertySource
  static void postgresProperties(DynamicPropertyRegistry registry) {
    registry.add("spring.datasource.url", POSTGRES::getJdbcUrl);
    registry.add("spring.datasource.username", POSTGRES::getUsername);
    registry.add("spring.datasource.password", POSTGRES::getPassword);
    registry.add("spring.datasource.driver-class-name", () -> "org.postgresql.Driver");
  }

  @Autowired private DataSource dataSource;
  @Autowired private UserRepository users;
  @Autowired private TrainRepository trains;
  @Autowired private RouteStopRepository routeStops;
  @Autowired private StationRepository stations;
  @Autowired private BookingRepository bookings;
  @Autowired private PassengerRepository passengers;
  @Autowired private BookingCancellationService cancellations;
  @Autowired private CoachRepository coaches;
  @Autowired private BookingSeatRepository bookingSeats;
  @Autowired private AccountTokenRepository accountTokens;
  @Autowired private AuthService authService;
  @Autowired private JdbcTemplate jdbc;

  @BeforeEach
  void installMigration005Baseline() throws Exception {
    executeSql("../database/005_booking_concurrency.sql");
    executeSql("../database/009_reliability_and_idempotency.sql");
  }

  private void executeSql(String path) throws Exception {
    try (java.sql.Connection connection = dataSource.getConnection()) {
      ScriptUtils.executeSqlScript(connection,
          new FileSystemResource(Path.of(path)));
    }
  }

  @Test
  void databaseRejectsDuplicateIdempotencyKeysForOneUserButAllowsDifferentUsers() {
    String suffix = UUID.randomUUID().toString();
    User first = user("first-" + suffix + "@southrail.invalid", RoleName.ROLE_USER);
    User second = user("second-" + suffix + "@southrail.invalid", RoleName.ROLE_USER);
    Train train = train("IK" + suffix.substring(0, 4));
    Station source = station("IKS");
    Station destination = station("IKD");
    LocalDate date = LocalDate.now().plusDays(30);

    Booking firstBooking = queuedBooking(first, train, source, destination, date,
        "IDEMP-0001", BookingStatus.WAITLISTED, 1);
    firstBooking.setIdempotencyKey("shared-key");
    firstBooking.setIdempotencyFingerprint("a".repeat(64));
    bookings.saveAndFlush(firstBooking);

    Booking independent = queuedBooking(second, train, source, destination, date,
        "IDEMP-0002", BookingStatus.WAITLISTED, 2);
    independent.setIdempotencyKey("shared-key");
    independent.setIdempotencyFingerprint("b".repeat(64));
    bookings.saveAndFlush(independent);

    assertThatThrownBy(() -> jdbc.update(
        "insert into bookings (id, pnr, user_id, train_id, source_station_id, destination_station_id, "
            + "journey_date, travel_class, quota, status, total_fare, idempotency_key, "
            + "idempotency_fingerprint, created_at, updated_at) "
            + "select gen_random_uuid(), 'IDEMP-0003', user_id, train_id, source_station_id, "
            + "destination_station_id, journey_date, travel_class, quota, status, total_fare, "
            + "idempotency_key, idempotency_fingerprint, now(), now() from bookings where id = ?",
        firstBooking.getId())).isInstanceOf(org.springframework.dao.DataIntegrityViolationException.class);
  }

  @Test
  void waitlistPromotionIsFlushSafeAgainstPostgresPartialIndexes() throws Exception {
    User user = user();
    Train train = train();
    Station source = station("SRC");
    Station destination = station("DST");
    LocalDate date = LocalDate.now().plusDays(30);
    ensureBookableRoute(train, source, destination);

    Booking rac1 = queuedBooking(user, train, source, destination, date, "RAC-000001", BookingStatus.RAC, 1);
    Booking rac2 = queuedBooking(user, train, source, destination, date, "RAC-000002", BookingStatus.RAC, 2);
    Booking wl1 = queuedBooking(user, train, source, destination, date, "WL-0000001", BookingStatus.WAITLISTED, 1);
    Booking wl2 = queuedBooking(user, train, source, destination, date, "WL-0000002", BookingStatus.WAITLISTED, 2);
    passenger(rac1, BookingStatus.RAC, "RAC One");
    passenger(rac2, BookingStatus.RAC, "RAC Two");
    passenger(wl1, BookingStatus.WAITLISTED, "WL One");
    passenger(wl2, BookingStatus.WAITLISTED, "WL Two");
    executeSql("../database/006_queue_and_token_concurrency.sql");

    cancellations.cancel(user.getEmail(), rac2.getPnr());

    List<Map<String, Object>> queue = jdbc.queryForList(
        "select pnr, status, queue_position, reservation_label from bookings "
            + "where train_id = ? and journey_date = ? and travel_class = ? and status = 'RAC' "
            + "order by queue_position",
        train.getId(), date, "3A");
    assertThat(queue).extracting(row -> row.get("pnr"))
        .containsExactly(rac1.getPnr(), wl1.getPnr(), wl2.getPnr());
    assertThat(queue).extracting(row -> ((Number) row.get("queue_position")).intValue())
        .containsExactly(1, 2, 3);
    assertThat(queue).extracting(row -> row.get("reservation_label"))
        .containsExactly("RAC 1", "RAC 2", "RAC 3");
    assertThat(jdbc.queryForObject(
        "select count(*) from (select queue_position from bookings where train_id = ? "
            + "and journey_date = ? and travel_class = ? and status = 'RAC' "
            + "group by queue_position having count(*) > 1) duplicates",
        Integer.class, train.getId(), date, "3A")).isZero();
    assertThat(jdbc.queryForList(
        "select b.status as booking_status, p.status as passenger_status from bookings b "
            + "join passengers p on p.booking_id = b.id where b.id in (?, ?, ?)",
        rac1.getId(), wl1.getId(), wl2.getId()))
        .allSatisfy(row -> assertThat(row.get("passenger_status")).isEqualTo(row.get("booking_status")));
  }

  @Test
  void adminCancellationKeepsLazyBookingOwnerAvailableAfterQueueClear() throws Exception {
    User admin = user("queue-admin@southrail.invalid", RoleName.ROLE_ADMIN);
    User customer = user("queue-customer@southrail.invalid", RoleName.ROLE_USER);
    Train train = train("PG4402");
    Station source = station("ASRC");
    Station destination = station("ADST");
    LocalDate date = LocalDate.now().plusDays(31);
    ensureBookableRoute(train, source, destination);
    Booking cancelled = queuedBooking(
        customer, train, source, destination, date, "ADMIN-RAC-1", BookingStatus.RAC, 1);
    Booking waiting = queuedBooking(
        customer, train, source, destination, date, "ADMIN-WL-1", BookingStatus.WAITLISTED, 1);
    Passenger cancelledPassenger = passenger(cancelled, BookingStatus.RAC, "Cancelled Customer");
    Passenger waitingPassenger = passenger(waiting, BookingStatus.WAITLISTED, "Waiting Customer");
    executeSql("../database/006_queue_and_token_concurrency.sql");

    cancellations.cancel(admin.getEmail(), cancelled.getPnr());

    Map<String, Object> promoted = jdbc.queryForMap(
        "select status, queue_position, reservation_label from bookings where id = ?", waiting.getId());
    assertThat(promoted.get("status")).isEqualTo("RAC");
    assertThat(((Number) promoted.get("queue_position")).intValue()).isEqualTo(1);
    assertThat(promoted.get("reservation_label")).isEqualTo("RAC 1");
    assertThat(jdbc.queryForObject("select status from bookings where id = ?", String.class,
        cancelled.getId())).isEqualTo("CANCELLED");
    assertThat(jdbc.queryForObject("select status from passengers where id = ?", String.class,
        cancelledPassenger.getId())).isEqualTo("CANCELLED");
    assertThat(jdbc.queryForObject("select status from passengers where id = ?", String.class,
        waitingPassenger.getId())).isEqualTo("RAC");
    assertThat(jdbc.queryForObject(
        "select username from audit_logs where action = 'BOOKING_CANCELLED' and description like ?",
        String.class, "%" + cancelled.getPnr())).isEqualTo(customer.getEmail());
  }

  @Test
  void migration006UpgradesAnExisting005DatabaseWithoutReplayingEarlierMigrations() throws Exception {
    User customer = user("upgrade-customer@southrail.invalid", RoleName.ROLE_USER);
    Train train = train("PG4403");
    Station source = station("USRC");
    Station destination = station("UDST");
    LocalDate date = LocalDate.now().plusDays(32);
    Booking rac1 = queuedBooking(customer, train, source, destination, date,
        "UP-RAC-001", BookingStatus.RAC, 1);
    Booking rac2 = queuedBooking(customer, train, source, destination, date,
        "UP-RAC-002", BookingStatus.RAC, 2);
    Booking wl1 = queuedBooking(customer, train, source, destination, date,
        "UP-WL-0001", BookingStatus.WAITLISTED, 1);
    Booking wl2 = queuedBooking(customer, train, source, destination, date,
        "UP-WL-0002", BookingStatus.WAITLISTED, 1_000_001);
    passenger(rac1, BookingStatus.RAC, "Upgrade RAC One");
    passenger(rac2, BookingStatus.RAC, "Upgrade RAC Two");
    passenger(wl1, BookingStatus.WAITLISTED, "Upgrade WL One");
    passenger(wl2, BookingStatus.WAITLISTED, "Upgrade WL Two");
    List<String> orderBefore = queueOrder(train, date);

    assertThat(jdbc.queryForObject(
        "select count(*) from pg_constraint where conname = 'ck_bookings_rac_capacity'",
        Integer.class)).isEqualTo(1);
    executeSql("../database/006_queue_and_token_concurrency.sql");

    assertThat(jdbc.queryForObject(
        "select count(*) from pg_constraint where conname = 'ck_bookings_rac_capacity'",
        Integer.class)).isZero();
    assertThat(queueOrder(train, date)).containsExactlyElementsOf(orderBefore);
    assertThat(jdbc.queryForList(
        "select indexname from pg_indexes where schemaname = current_schema() and indexname in "
            + "('uq_bookings_rac_queue_position', 'uq_bookings_waitlist_queue_position', "
            + "'uq_account_tokens_one_open_per_type') order by indexname",
        String.class)).containsExactly(
            "uq_account_tokens_one_open_per_type",
            "uq_bookings_rac_queue_position",
            "uq_bookings_waitlist_queue_position");
    assertThat(jdbc.queryForObject(
        "select count(*) from pg_index i join pg_class c on c.oid = i.indexrelid "
            + "where c.relname in ('uq_bookings_rac_queue_position', "
            + "'uq_bookings_waitlist_queue_position', 'uq_account_tokens_one_open_per_type') "
            + "and not i.indisvalid",
        Integer.class)).isZero();
    String helper = Files.readString(Path.of("../deploy/upgrade_v0.2.2.sh"));
    assertThat(helper).contains("006_queue_and_token_concurrency.sql")
        .doesNotContain("004_foundation_schema.sql", "005_booking_concurrency.sql");
  }

  @Test
  void cancellationStabilizesNewlyPromotedRacUntilNoEligibleSeatIsIdle() throws Exception {
    User customer = user("stabilize@southrail.invalid", RoleName.ROLE_USER);
    Train train = train("PG4404");
    Station source = station("SSRC");
    Station destination = station("SDST");
    LocalDate date = LocalDate.now().plusDays(33);
    ensureBookableRoute(train, source, destination);
    Coach coach = coach(train, "S1", 5);
    Booking confirmed = queuedBooking(customer, train, source, destination, date,
        "ST-CNF-001", BookingStatus.CONFIRMED, 0);
    confirmed.setQueuePosition(null);
    confirmed.setReservationLabel("CNF");
    bookings.saveAndFlush(confirmed);
    for (int seat = 1; seat <= 5; seat++) {
      Passenger passenger = passenger(confirmed, BookingStatus.CONFIRMED, "Confirmed " + seat);
      bookedSeat(confirmed, passenger, coach, seat);
    }
    Booking rac = queuedBooking(customer, train, source, destination, date,
        "ST-RAC-001", BookingStatus.RAC, 1);
    passenger(rac, BookingStatus.RAC, "Existing RAC");
    Booking wl1 = queuedBooking(customer, train, source, destination, date,
        "ST-WL-0001", BookingStatus.WAITLISTED, 1);
    passenger(wl1, BookingStatus.WAITLISTED, "Waitlist One");
    passenger(wl1, BookingStatus.WAITLISTED, "Waitlist Two");
    Booking wl2 = queuedBooking(customer, train, source, destination, date,
        "ST-WL-0002", BookingStatus.WAITLISTED, 2);
    passenger(wl2, BookingStatus.WAITLISTED, "Waitlist Three");
    passenger(wl2, BookingStatus.WAITLISTED, "Waitlist Four");
    executeSql("../database/006_queue_and_token_concurrency.sql");

    cancellations.cancel(customer.getEmail(), confirmed.getPnr());

    assertThat(jdbc.queryForList(
        "select status from bookings where id in (?, ?, ?)", String.class,
        rac.getId(), wl1.getId(), wl2.getId())).containsOnly("CONFIRMED");
    assertThat(jdbc.queryForObject(
        "select count(*) from passengers where booking_id in (?, ?, ?) and status <> 'CONFIRMED'",
        Integer.class, rac.getId(), wl1.getId(), wl2.getId())).isZero();
    assertThat(jdbc.queryForObject(
        "select count(*) from booking_seats where train_id = ? and journey_date = ? and status = 'BOOKED'",
        Integer.class, train.getId(), date)).isEqualTo(5);
    assertThat(jdbc.queryForObject(
        "select count(*) from bookings where train_id = ? and journey_date = ? "
            + "and status in ('RAC', 'WAITLISTED')",
        Integer.class, train.getId(), date)).isZero();
  }

  @Test
  void runtimeWaitlistCompactionDoesNotCollideWithLargeExistingPositions() throws Exception {
    User customer = user("large-runtime-queue@southrail.invalid", RoleName.ROLE_USER);
    Train train = train("PG4405");
    Station source = station("LSRC");
    Station destination = station("LDST");
    LocalDate date = LocalDate.now().plusDays(34);
    ensureBookableRoute(train, source, destination);
    Booking fullRac = queuedBooking(customer, train, source, destination, date,
        "LG-RAC-0001", BookingStatus.RAC, 1);
    for (int occupant = 1; occupant <= BookingService.RAC_LIMIT; occupant++) {
      passenger(fullRac, BookingStatus.RAC, "RAC Occupant " + occupant);
    }
    Booking first = queuedBooking(customer, train, source, destination, date,
        "LG-WL-00001", BookingStatus.WAITLISTED, 1);
    Booking removed = queuedBooking(customer, train, source, destination, date,
        "LG-WL-00002", BookingStatus.WAITLISTED, 2);
    Booking large = queuedBooking(customer, train, source, destination, date,
        "LG-WL-00003", BookingStatus.WAITLISTED, 1_000_001);
    passenger(first, BookingStatus.WAITLISTED, "First Waiting");
    passenger(removed, BookingStatus.WAITLISTED, "Cancelled Waiting");
    passenger(large, BookingStatus.WAITLISTED, "Large Position Waiting");
    executeSql("../database/006_queue_and_token_concurrency.sql");
    // Migration 006 compacts legacy queues. Restore the deliberately large,
    // valid post-migration position needed to exercise runtime staging.
    jdbc.update("update bookings set queue_position = ?, reservation_label = ? where id = ?",
        1_000_001, "WL 1000001", large.getId());

    assertThat(jdbc.queryForObject(
        "select count(*) from passengers p join bookings b on b.id = p.booking_id "
            + "where b.id = ? and b.status = 'RAC' and p.status = 'RAC'",
        Integer.class, fullRac.getId())).isEqualTo(BookingService.RAC_LIMIT);
    assertThat(jdbc.queryForList(
        "select queue_position from bookings where train_id = ? and journey_date = ? "
            + "and status = 'WAITLISTED' order by queue_position",
        Integer.class, train.getId(), date)).containsExactly(1, 2, 1_000_001);

    cancellations.cancel(customer.getEmail(), removed.getPnr());

    List<Map<String, Object>> queue = jdbc.queryForList(
        "select pnr, queue_position, reservation_label from bookings where train_id = ? "
            + "and journey_date = ? and status = 'WAITLISTED' order by queue_position",
        train.getId(), date);
    assertThat(queue).extracting(row -> row.get("pnr"))
        .containsExactly(first.getPnr(), large.getPnr());
    assertThat(queue).extracting(row -> ((Number) row.get("queue_position")).intValue())
        .containsExactly(1, 2);
    assertThat(queue).extracting(row -> row.get("reservation_label"))
        .containsExactly("WL 1", "WL 2");
  }

  @Test
  void concurrentCancellationsPromoteDistinctWaitlistedPartiesToDistinctSeats() throws Exception {
    User customer = user("concurrent-promotion@southrail.invalid", RoleName.ROLE_USER);
    Train train = train("PG4406");
    Station source = station("CSRC");
    Station destination = station("CDST");
    LocalDate date = LocalDate.now().plusDays(35);
    ensureBookableRoute(train, source, destination);
    Coach coach = coach(train, "C1", 2);

    Booking confirmedOne = queuedBooking(customer, train, source, destination, date,
        "CC-CNF-0001", BookingStatus.CONFIRMED, 0);
    confirmedOne.setQueuePosition(null);
    confirmedOne.setReservationLabel("CNF");
    bookings.saveAndFlush(confirmedOne);
    bookedSeat(confirmedOne, passenger(confirmedOne, BookingStatus.CONFIRMED, "Confirmed One"), coach, 1);
    Booking confirmedTwo = queuedBooking(customer, train, source, destination, date,
        "CC-CNF-0002", BookingStatus.CONFIRMED, 0);
    confirmedTwo.setQueuePosition(null);
    confirmedTwo.setReservationLabel("CNF");
    bookings.saveAndFlush(confirmedTwo);
    bookedSeat(confirmedTwo, passenger(confirmedTwo, BookingStatus.CONFIRMED, "Confirmed Two"), coach, 2);

    Booking waitlistOne = queuedBooking(customer, train, source, destination, date,
        "CC-WL-00001", BookingStatus.WAITLISTED, 1);
    Passenger waitingOne = passenger(waitlistOne, BookingStatus.WAITLISTED, "Waiting One");
    Booking waitlistTwo = queuedBooking(customer, train, source, destination, date,
        "CC-WL-00002", BookingStatus.WAITLISTED, 2);
    Passenger waitingTwo = passenger(waitlistTwo, BookingStatus.WAITLISTED, "Waiting Two");
    executeSql("../database/006_queue_and_token_concurrency.sql");

    java.util.concurrent.ExecutorService executor = java.util.concurrent.Executors.newFixedThreadPool(2);
    try {
      java.util.concurrent.Future<?> first = executor.submit(
          () -> cancellations.cancel(customer.getEmail(), confirmedOne.getPnr()));
      java.util.concurrent.Future<?> second = executor.submit(
          () -> cancellations.cancel(customer.getEmail(), confirmedTwo.getPnr()));
      first.get(20, java.util.concurrent.TimeUnit.SECONDS);
      second.get(20, java.util.concurrent.TimeUnit.SECONDS);
    } finally {
      executor.shutdownNow();
    }

    assertThat(jdbc.queryForList(
        "select status from bookings where id in (?, ?)", String.class,
        waitlistOne.getId(), waitlistTwo.getId())).containsOnly("CONFIRMED");
    assertThat(jdbc.queryForObject(
        "select count(distinct coach_id || ':' || seat_number) from booking_seats "
            + "where passenger_id in (?, ?) and status = 'BOOKED'",
        Integer.class, waitingOne.getId(), waitingTwo.getId())).isEqualTo(2);
    assertThat(jdbc.queryForObject(
        "select count(*) from booking_seats where passenger_id in (?, ?) and status = 'BOOKED'",
        Integer.class, waitingOne.getId(), waitingTwo.getId())).isEqualTo(2);
    assertThat(jdbc.queryForObject(
        "select count(*) from audit_logs where action = 'WAITLIST_PROMOTED' "
            + "and (description like ? or description like ?)",
        Integer.class, "%" + waitlistOne.getPnr() + "%", "%" + waitlistTwo.getPnr() + "%"))
        .isEqualTo(2);
    assertThat(jdbc.queryForList(
        "select description from audit_logs where action = 'WAITLIST_PROMOTED' "
            + "and (description like ? or description like ?)",
        String.class, "%" + waitlistOne.getPnr() + "%", "%" + waitlistTwo.getPnr() + "%"))
        .allSatisfy(description -> assertThat(description).contains("promoted to CONFIRMED"));
    for (Booking promoted : List.of(waitlistOne, waitlistTwo)) {
      assertThat(jdbc.queryForObject(
          "select count(*) from audit_logs where action = 'WAITLIST_PROMOTED' and description like ?",
          Integer.class, "%" + promoted.getPnr() + "%")).isEqualTo(1);
      assertThat(jdbc.queryForObject(
          "select count(*) from notifications where user_id = ? "
              + "and title = 'Waitlist booking confirmed' and message like ?",
          Integer.class, customer.getId(), "%" + promoted.getPnr() + "%")).isEqualTo(1);
    }
    assertThat(jdbc.queryForObject(
        "select count(*) from notifications where user_id = ? "
            + "and title = 'Waitlist booking confirmed' and (message like ? or message like ?)",
        Integer.class, customer.getId(), "%" + waitlistOne.getPnr() + "%",
        "%" + waitlistTwo.getPnr() + "%")).isEqualTo(2);
  }

  @Test
  void deletedAccountCannotUsePreviouslyIssuedPasswordResetToken() throws Exception {
    executeSql("../database/006_queue_and_token_concurrency.sql");
    User deleted = user("deleted-reset@southrail.invalid", RoleName.ROLE_USER);
    deleted.setDeleted(true);
    deleted.setEnabled(false);
    users.saveAndFlush(deleted);
    String rawToken = "previously-issued-reset-token";
    AccountToken token = new AccountToken();
    token.setUser(deleted);
    token.setTokenType("RESET_PASSWORD");
    token.setTokenHash(sha256(rawToken));
    token.setExpiresAt(Instant.now().plusSeconds(600));
    token = accountTokens.saveAndFlush(token);

    org.junit.jupiter.api.Assertions.assertThrows(ApiException.class,
        () -> authService.resetPassword(new AuthDtos.ResetPasswordRequest(rawToken, "new-password")));

    assertThat(accountTokens.findById(token.getId()).orElseThrow().getUsedAt()).isNotNull();
  }

  private String sha256(String value) throws Exception {
    byte[] digest = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
    StringBuilder result = new StringBuilder();
    for (byte item : digest) result.append(String.format("%02x", item & 0xff));
    return result.toString();
  }

  private List<String> queueOrder(Train train, LocalDate date) {
    return jdbc.queryForList(
        "select pnr from bookings where train_id = ? and journey_date = ? "
            + "and status in ('RAC', 'WAITLISTED') order by status, queue_position",
        String.class, train.getId(), date);
  }

  private User user() {
    return user("postgres-queue@southrail.invalid", RoleName.ROLE_USER);
  }

  private User user(String email, RoleName role) {
    User user = new User();
    user.setEmail(email);
    user.setFullName("Queue Owner");
    user.setPasswordHash("not-used");
    user.setEmailVerified(true);
    user.getRoles().add(role);
    return users.saveAndFlush(user);
  }

  private Train train() {
    return train("PG4401");
  }

  private Train train(String number) {
    Train train = new Train();
    train.setNumber(number);
    train.setName("Postgres Queue Express");
    train.setCategory("TEST");
    return trains.saveAndFlush(train);
  }

  private Station station(String code) {
    Station station = new Station();
    station.setCode(code);
    station.setName(code + " Station");
    station.setCity("Test City");
    station.setState("Test State");
    return stations.saveAndFlush(station);
  }

  private Coach coach(Train train, String code, int capacity) {
    Coach coach = new Coach();
    coach.setTrain(train);
    coach.setCoachCode(code);
    coach.setTravelClass("3A");
    coach.setCapacity(capacity);
    return coaches.saveAndFlush(coach);
  }

  private BookingSeat bookedSeat(Booking booking, Passenger passenger, Coach coach, int seatNumber) {
    BookingSeat seat = new BookingSeat();
    seat.setBooking(booking);
    seat.setPassenger(passenger);
    seat.setCoach(coach);
    seat.setTrain(booking.getTrain());
    seat.setJourneyDate(booking.getJourneyDate());
    seat.setTravelClass(booking.getTravelClass());
    seat.setCoachCode(coach.getCoachCode());
    seat.setSeatNumber(seatNumber);
    seat.setStatus(BookingSeatStatus.BOOKED);
    return bookingSeats.saveAndFlush(seat);
  }

  private Booking queuedBooking(User user, Train train, Station source, Station destination,
      LocalDate date, String pnr, BookingStatus status, int position) {
    Booking booking = new Booking();
    booking.setUser(user);
    booking.setTrain(train);
    booking.setSourceStation(source);
    booking.setDestinationStation(destination);
    booking.setJourneyDate(date);
    booking.setTravelClass("3A");
    booking.setQuota("GENERAL");
    booking.setPnr(pnr);
    booking.setStatus(status);
    booking.setQueuePosition(position);
    booking.setReservationLabel(status == BookingStatus.RAC ? "RAC " + position : "WL " + position);
    booking.setTotalFare(BigDecimal.valueOf(100));
    return bookings.saveAndFlush(booking);
  }

  private void ensureBookableRoute(Train train, Station source, Station destination) {
    if (routeStops.findFirstByTrainAndStationOrderByStopOrderAsc(train, source).isPresent()) {
      return;
    }
    RouteStop sourceStop = new RouteStop();
    sourceStop.setTrain(train);
    sourceStop.setStation(source);
    sourceStop.setStopOrder(1);
    sourceStop.setDepartureTime(LocalTime.NOON);
    sourceStop.setDistanceKm(0);

    RouteStop destinationStop = new RouteStop();
    destinationStop.setTrain(train);
    destinationStop.setStation(destination);
    destinationStop.setStopOrder(2);
    destinationStop.setArrivalTime(LocalTime.of(14, 0));
    destinationStop.setDistanceKm(100);
    routeStops.saveAllAndFlush(List.of(sourceStop, destinationStop));
  }

  private Passenger passenger(Booking booking, BookingStatus status, String name) {
    Passenger passenger = new Passenger();
    passenger.setBooking(booking);
    passenger.setFullName(name);
    passenger.setAge(30);
    passenger.setGender("other");
    passenger.setStatus(status);
    return passengers.saveAndFlush(passenger);
  }
}
